"""Compatibility import for GUI consumers of shared resource paths."""
from common.core.tools.ResourcePath import ResourcePath
