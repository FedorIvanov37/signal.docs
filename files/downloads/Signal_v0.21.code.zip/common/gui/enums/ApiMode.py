from common.api.enums.ApiModes import ApiModes, ApiModeNames
