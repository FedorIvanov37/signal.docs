from enum import StrEnum


class Colors(StrEnum):
    RED = "#ff0000"
    BLACK = "#000000"
    BLUE = "#0000FF"
    SELECTION_BLUE = "#0078D7"
    WHITE = "#FFFFFF"
    CONSOLE_BACKGROUND = "#011627"
    CONSOLE_TEXT = "#D6DEEB"
    DEEP_RED = "#800000"
    LIGHT_GREY = "#E0E9F6"
    GREY = "#9A9A9A"
