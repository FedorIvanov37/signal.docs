from enum import StrEnum


class KeySequences(StrEnum):
    CTRL_T = "Ctrl+T"
    CTRL_R = "Ctrl+R"
    CTRL_L = "Ctrl+L"
    CTRL_E = "Ctrl+E"
    CTRL_W = "Ctrl+W"
    CTRL_Q = "Ctrl+Q"
    CTRL_D = "Ctrl+D"
    CTRL_ALT_Q = "Ctrl+Alt+Q"
    CTRL_ENTER = "Ctrl+Return"
    CTRL_SHIFT_ENTER = "Ctrl+Shift+Return"
    CTRL_SHIFT_N = "Ctrl+Shift+N"
    CTRL_ALT_ENTER = "Ctrl+Alt+Return"
    CTRL_ALT_V = "Ctrl+Alt+V"
    CTRL_PAGE_UP = "Ctrl+PgUp"
    CTRL_PAGE_DOWN = "Ctrl+PgDown"
    CTRL_ALT_P = "Ctrl+Alt+P"
    CTRL_TAB = "Ctrl+Tab"
    CTRL_SHIFT_TAB = "Ctrl+Shift+Tab"
