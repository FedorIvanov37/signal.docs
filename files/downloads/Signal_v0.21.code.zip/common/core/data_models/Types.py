FieldPath = list[str]
