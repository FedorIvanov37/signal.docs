from pydantic import BaseModel, Field, field_validator, ConfigDict
from common.core.data_models.Types import FieldPath
from common.core.decorators.json_file_model import json_file_model
from typing import ForwardRef
from enum import Enum


FieldSet = dict[str, ForwardRef("IsoField")]
RawFieldSet = dict[str, str | dict]
MtiValue = Field(default="", max_length=4, pattern=r"^\d{4}|$")
literal_list = list[str]


class FieldTypes(str, Enum):
    COUNTRY_CODE = "COUNTRY CODE"
    CURRENCY_CODE = "CURRENCY CODE"
    MERCHANT_CATEGORY_CODE = "MERCHANT CATEGORY CODE"
    DATE = "DATE"
    OTHER = "OTHER"


class Justification(str, Enum):
    LEFT = "LEFT"
    RIGHT = "RIGHT"
    CUSTOM = "CUSTOM"


class Mti(BaseModel):
    request: str = MtiValue
    response: str = MtiValue
    description: str = str()
    is_reversible: bool = False
    reversal_mti: str = MtiValue


class LogicalValidators(BaseModel):
    currency_a3: bool = False
    currency_n3: bool = False
    country_a3: bool = False
    country_a2: bool = False
    country_n3: bool = False
    mcc: bool = False
    date_format: str = ""
    past: bool = False
    present: bool = False
    future: bool = False
    check_luhn: bool = False
    only_upper: bool = False
    only_lower: bool = False
    change_to_upper: bool = False
    change_to_lower: bool = False
    do_not_validate: bool = False


class Validators(BaseModel):
    field_type: FieldTypes | None = None
    date_format: str | None = None
    min_value: int = 0
    max_value: int = 0
    must_not_contain: literal_list = list()
    possible_values: literal_list = list()
    must_start_with: literal_list = list()
    must_end_with: literal_list = list()
    must_contain: literal_list = list()
    valid_values: literal_list = list()
    invalid_values: literal_list = list()
    must_contain_only: literal_list = list()
    must_not_end_with: literal_list = list()
    must_not_start_with: literal_list = list()
    must_not_contain_only: literal_list = list()
    justification: Justification | None = None
    justification_element: str | None = None
    justification_length: int = 0
    field_type_validators: LogicalValidators | None = LogicalValidators()

    @field_validator("field_type_validators", mode="before")
    @classmethod
    def substitute_none_validator(cls, val):
        if val is None:
            return LogicalValidators()

        return val


class IsoField(BaseModel):
    model_config: ConfigDict = ConfigDict(validate_assignment=True)

    validators: Validators | None = Validators()
    field_number: str = ""
    field_path: list = []
    min_length: int
    max_length: int
    var_length: int
    tag_length: int
    generate: bool
    reversal: bool
    matching: bool
    alpha: bool
    numeric: bool
    special: bool
    reserved_for_future: bool
    description: str = str()
    is_secret: bool = False
    is_utrnno: bool = False
    fields: FieldSet | None = None

    @field_validator("is_secret", mode="before")
    @classmethod
    def substitute_none_by_bool(cls, val):
        if val is None:
            return False

        return val

    @field_validator("validators", mode="before")
    @classmethod
    def substitute_none_validator(cls, val):
        if val is None:
            return Validators()

        return val


@json_file_model
class EpaySpecModel(BaseModel):
    name: str | None = "ISO-8583 E-pay Specification"
    mti: list[Mti] = []
    fields: FieldSet = {}
    utrnno_path: FieldPath = ["47", "064"]

    def validate_for_use(self):
        """Reject unusable data before installing it in a running terminal."""
        from string import printable
        errors = []
        if not self.fields:
            errors.append('Specification must contain fields')

        def text_values(value, location='Specification'):
            if isinstance(value, str) and any(character not in printable for character in value):
                errors.append(f'{location}: non-printable characters; check the encoding')
            elif isinstance(value, dict):
                for key, child in value.items():
                    text_values(key, location)
                    text_values(child, f'{location}.{key}')
            elif isinstance(value, list):
                for child in value:
                    text_values(child, location)

        text_values(self.model_dump())

        def fields(values, parent=()):
            seen = set()
            for number, field in values.items():
                location = f'Field {".".join((*parent, number))}'
                if field.field_number != number:
                    errors.append(f'Field entry {number!r}: field_number {field.field_number!r} does not match its key')
                if not number or not number.isascii() or not number.isdigit() or int(number) < 1:
                    errors.append(f'Invalid field number {number!r}')
                elif not parent and not 2 <= int(number) <= 128 and number != '1':
                    errors.append(f'Invalid field number {number!r}: allowed range 2-128')
                else:
                    if int(number) in seen:
                        errors.append(f'Duplicated field number {number!r}')
                    seen.add(int(number))
                if not field.reserved_for_future and number != '1':
                    lengths = (field.min_length, field.max_length, field.var_length, field.tag_length)
                    if any(not isinstance(value, int) or isinstance(value, bool) for value in lengths):
                        errors.append(f'{location}: lengths must be integers')
                    else:
                        if field.min_length < 1 or field.max_length < field.min_length:
                            errors.append(f'{location}: invalid Min/Max Length')
                        if field.var_length < 0 or field.tag_length < 0:
                            errors.append(f'{location}: negative length')
                        if field.tag_length > 0 and not field.fields:
                            errors.append(f'{location}: Non-zero Tag Len without subfields')
                    if not any((field.alpha, field.numeric, field.special)):
                        errors.append(f'{location}: Missing field data type')
                if field.fields:
                    fields(field.fields, (*parent, number))

        fields(self.fields)
        if errors:
            raise ValueError('Invalid specification:\n' + '\n'.join(errors))
